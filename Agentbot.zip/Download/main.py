import os
from slack_bolt import App
from slack_bolt.adapter.flask import SlackRequestHandler
from flask import Flask, request
import openai

# 🔑 Load secrets (set them in Replit Secrets)
SLACK_BOT_TOKEN = os.environ.get("SLACK_BOT_TOKEN")       # xoxb-...
SLACK_SIGNING_SECRET = os.environ.get("SLACK_SIGNING_SECRET")
BOT_USER_ID = os.environ.get("BOT_USER_ID")               # U...
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")

# Init Slack + OpenAI
app = App(token=SLACK_BOT_TOKEN, signing_secret=SLACK_SIGNING_SECRET)
openai.api_key = OPENAI_API_KEY

# --- Handle messages ---
@app.event("message")
def handle_message_events(body, say):
    event = body.get("event", {})
    user = event.get("user")
    text = event.get("text", "")

    # Ignore bot's own messages
    if user and user != BOT_USER_ID and text.strip():
        try:
            # Send user text to OpenAI
            response = openai.ChatCompletion.create(
                model="gpt-4o-mini",   # fast & cheap model for hackathon
                messages=[
                    {"role": "system", "content": "You are AgentBot, a friendly helpful teammate for a hackathon project."},
                    {"role": "user", "content": text}
                ],
                max_tokens=200
            )

            reply = response.choices[0].message["content"]
            say(f"<@{user}> {reply}")

        except Exception as e:
            say(f"⚠️ Sorry <@{user}>, I had an error: {e}")

# --- Flask for Slack Events ---
flask_app = Flask(__name__)
handler = SlackRequestHandler(app)

@flask_app.route("/slack/events", methods=["POST"])
def slack_events():
    return handler.handle(request)

if __name__ == "__main__":
    flask_app.run(host="0.0.0.0", port=3000)